import json
from pathlib import Path

LEARNING_DB = Path("learning_db.json")


def load_runtime_history():

    if not LEARNING_DB.exists():
        return {}

    try:
        with open(LEARNING_DB, "r", encoding="utf-8") as f:
            return json.load(f)

    except Exception:
        return {}


def save_runtime_history(history):

    with open(LEARNING_DB, "w", encoding="utf-8") as f:

        json.dump(history, f, ensure_ascii=False, indent=2)