from pathlib import Path
from collections import Counter

from classifier.similarity_engine import tokenize, extract_features

import pandas as pd

from modules.product_card import ProductCard


def confirm_learning(
        self,
        card,
        corrected_description,
        corrected_code,
        corrected_material
):
    key = corrected_description.lower().strip()

    item = self.history.setdefault(
        key,
        {
            "codes": Counter(),
            "materials": Counter()
        }
    )

    item["codes"][corrected_code] += 1

    if corrected_material:
        item["materials"][corrected_material.lower()] += 1


def import_verified_file(self, excel_path):
    df = pd.read_excel(excel_path)

    desc_col = df.columns[1]
    code_col = df.columns[2]

    for _, row in df.iterrows():

        description = str(row[desc_col]).strip()

        if not description:
            continue

        code = str(row[code_col]).strip()

        if (
                not code
                or code == "0"
                or code.lower() == "nan"
        ):
            continue

        self.confirm_learning(
            card=None,
            corrected_description=description,
            corrected_code=code,
            corrected_material=""
        )

    export_learning_history(
        self.history,
        "LEARNING_HISTORY.xlsx"
    )
def load_learning_history(input_path: str) -> dict:

    history = {}

    try:
        df = pd.read_excel(input_path)

    except Exception:
        return history

    columns = {str(c).lower(): c for c in df.columns}

    desc_col = next(
        (
            columns[c]
            for c in columns
            if "опис" in c
        ),
        None
    )

    code_col = next(
        (
            columns[c]
            for c in columns
            if "тнвэд" in c
        ),
        None
    )

    material_col = next(
        (
            columns[c]
            for c in columns
            if "материал" in c
        ),
        None
    )

    if not desc_col:
        return history

    for _, row in df.iterrows():

        description = str(
            row.get(desc_col, "")
        ).strip()

        name = description.lower()

        if not name:
            continue

        card = ProductCard()

        card.title = description
        card.cleaned_text = description

        if material_col:

            material = str(
                row.get(material_col, "")
            ).strip()

            if material and material.lower() != "nan":
                card.specs["Материал"] = material

        if name not in history:
            history[name] = {
                "description": description,
                "tokens": tokenize(card.cleaned_text),
                "features": extract_features(card),
                "codes": Counter(),
                "materials": Counter()
            }

        if code_col:

            code = str(
                row.get(code_col, "")
            ).strip()

            if code and code != "0" and code.lower() != "nan":
                history[name]["codes"][code] += 1

        material = (
                card.specs.get("Материал")
                or ""
        ).strip().lower()

        if material:
            history[name]["materials"][material] += 1

    return history


LEARNING_HISTORY_DB = Path("learning_history.json")

def export_learning_history(history, output):

    rows = []

    for name, info in history.items():

        for code, count in info["codes"].items():

            rows.append({

                "Описание": name,
                "Код": code,
                "Количество": count,
                "Материалы": ", ".join(
                    f"{m}:{c}"
                    for m, c in info["materials"].items()
                )

            })

    pd.DataFrame(rows).to_excel(
        output,
        index=False
    )


