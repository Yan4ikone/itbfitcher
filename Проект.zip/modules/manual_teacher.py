import pandas as pd

from repositories.manual_repository import ManualRepository


def learn_from_result_file(path):

    repository = ManualRepository()
    db = repository.get_all()
    df = pd.read_excel(path)

    for _, row in df.iterrows():

        url = str(row["Ссылка"]).strip()
        description = str(row["Описание"]).strip()
        code = str(row["Тнвэд"]).strip()
        material = str(row.get("Материал", "")).strip()

        if not url:
            continue

        old = db.get(url, {})

        db[url] = {

            "url": url,
            "title": old.get("title", ""),
            "description": description,
            "code": code,
            "material": material,
            "approved": True
        }

    repository.save_all(db)